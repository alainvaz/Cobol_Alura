# cursoopencobol
Curso de Cobol para plataforma OPEN 
